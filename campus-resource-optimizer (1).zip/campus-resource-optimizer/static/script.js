/**
 * script.js - Client-Side Interactivity
 * Campus Resource Optimizer - BCA (AI & DS) College Project
 */

// Function to populate and open Edit Resource Modal
function openEditModal(resourceId, name, resourceType, capacity, building, floor, equipment, status) {
    const form = document.getElementById('editResourceForm');
    if (!form) return;

    // Set action URL to the corresponding edit route
    form.action = `/resources/edit/${encodeURIComponent(resourceId)}`;

    // Set modal title
    const modalTitle = document.getElementById('editModalTitle');
    if (modalTitle) {
        modalTitle.innerText = `Edit Resource: ${resourceId}`;
    }

    // Populate input fields
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_type').value = resourceType;
    document.getElementById('edit_capacity').value = capacity;
    document.getElementById('edit_building').value = building;
    document.getElementById('edit_floor').value = floor;
    document.getElementById('edit_equipment').value = equipment === 'None' ? '' : equipment;
    document.getElementById('edit_status').value = status;

    // Trigger Bootstrap Modal
    const modalElement = document.getElementById('editResourceModal');
    if (modalElement) {
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
    }
}

// On DOM ready initializations
document.addEventListener('DOMContentLoaded', function () {
    // 1. Auto-set today's date as default in booking form if date input is empty
    const dateInput = document.getElementById('booking_date');
    if (dateInput && !dateInput.value) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
        dateInput.min = today; // Prevent booking in the past
    }

    // 2. Client-side validation: Check that start time is before end time
    const bookingForm = document.querySelector('form[action*="/bookings/add"]');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function (e) {
            const startTimeInput = document.querySelector('input[name="start_time"]');
            const endTimeInput = document.querySelector('input[name="end_time"]');

            if (startTimeInput && endTimeInput && startTimeInput.value && endTimeInput.value) {
                if (startTimeInput.value >= endTimeInput.value) {
                    e.preventDefault();
                    alert('⚠️ Invalid Time Slot: Start Time must be earlier than End Time.');
                }
            }
        });
    }
});
