# 🏫 Campus Resource Optimizer

A simple, clean, and beginner-friendly web application built for the **BCA (Artificial Intelligence & Data Science)** college project.

---

## 📌 1. Project Overview

The **Campus Resource Optimizer** solves real-world campus resource scheduling problems by allowing college administrators and faculty to:
- **Track Campus Resources:** Manage classrooms, computer labs, seminar halls, and auditoriums with their capacity and equipment.
- **Prevent Double Booking:** Automatically detect overlapping booking slots and prevent scheduling conflicts.
- **Enforce Capacity Limits:** Guarantee student count never exceeds room capacity.
- **Smart Resource Recommendation:** Recommend the most optimal room based on group size, room type, and required equipment using fundamental **Data Structures & Algorithms (DSA)**.
- **Future AI/ML Readiness:** Demonstrate how historical college booking records can be used to forecast resource demand.

---

## 💻 2. Technology Stack

- **Frontend:** HTML5, CSS3, JavaScript (Bootstrap 5 for clean responsive cards and tables)
- **Backend:** Python, Flask
- **Database:** MySQL
- **Optional ML:** Python, Pandas, Scikit-learn

---

## 📂 3. Project Folder Structure

```text
campus-resource-optimizer/
│
├── app.py                  # Main Flask application (routes, conflict logic, DSA sorting & queue)
├── database.py             # MySQL database connection helper using python-dotenv
├── requirements.txt        # Python package dependencies
├── README.md               # Complete setup, usage, and project documentation
├── .env.example            # Sample configuration for MySQL connection
│
├── database/
│   └── schema.sql          # MySQL database creation, tables, and realistic sample data
│
├── templates/
│   ├── index.html          # Dashboard: dynamic statistics cards and recent queue activity
│   ├── resources.html      # Resource management: table, search/filters, add and edit modals
│   ├── bookings.html       # Bookings: reservation form, conflict warnings, bookings table
│   └── recommendation.html # Recommendation: smart room suggestion and alternative rooms
│
├── static/
│   ├── style.css           # Clean custom styling (Blue, White, Light Grey palette)
│   └── script.js           # Client-side modal prefill, date helpers, and validation
│
└── ml/
    └── prediction.py       # Standalone prototype demonstrating ML demand forecasting
```

---

## ⚙️ 4. Installation & Setup Guide

### Step 1: Open Project in VS Code
Open VS Code, click **File > Open Folder...**, and select the `campus-resource-optimizer` folder.

### Step 2: Create and Activate Virtual Environment
Open the integrated terminal in VS Code (`Ctrl + ` `) and run:

```bash
# Create virtual environment
python -m venv venv

# Activate on Windows (PowerShell or Command Prompt)
venv\Scripts\activate
```

### Step 3: Install Required Dependencies
```bash
pip install -r requirements.txt
```

---

## 🗄️ 5. MySQL Database Setup

1. Open **MySQL Workbench** (or command-line MySQL client).
2. Open and execute the script located at:
   ```text
   database/schema.sql
   ```
   *This automatically creates the `campus_optimizer` database, `resources` and `bookings` tables, and populates realistic sample data.*

3. Create your `.env` configuration file:
   Copy `.env.example` to a new file named `.env`:
   ```text
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_actual_mysql_password
   DB_NAME=campus_optimizer
   SECRET_KEY=campus_resource_optimizer_secret_2026
   ```
   *Replace `your_actual_mysql_password` with your local MySQL root password.*

---

## 🚀 6. Running the Application

### Start the Flask Server
```bash
python app.py
```

### Open in Browser
Visit:
```text
http://127.0.0.1:5000
```

---

## 🧠 7. Data Structures & Algorithms (DSA) Implementation

To demonstrate practical Computer Science concepts for BCA students, this project implements:

1. **Searching & Filtering (`app.py` -> `get_resources()`):**
   Iterative multi-parameter search filtering campus resources by type, minimum capacity, building, and availability status.
2. **Sorting (`app.py` -> `get_resources()`, `recommend_resource()`):**
   Utilizes Python's $O(N \log N)$ sorting to rank resources by capacity, name, or availability. In the recommendation engine, candidate rooms are sorted by capacity difference `(capacity - student_count)` ascending to minimize empty wasted seats.
3. **Hash Table / Dictionary (`app.py` -> `get_resource_dict()`):**
   Constructs a dictionary indexed by `resource_id` for instantaneous $O(1)$ lookup when validating bookings.
4. **Queue / FIFO (`app.py` -> `booking_activity_queue`):**
   Uses `collections.deque` to maintain a First-In-First-Out queue of recent booking and cancellation activities shown on the dashboard.

---

## 🤖 8. Machine Learning Prototype (`ml/prediction.py`)

The ML script is completely independent of the web application. To run the demand forecasting demonstration:

```bash
python ml/prediction.py
```

**Concept Explained:**
- Collects historical booking logs (Day of Week, Hour of Day, Resource Type, Group Size).
- Trains a supervised `LinearRegression` model to predict the **Campus Utilization Score** (0–100%).
- Identifies high-demand peak hours to help college management schedule exams and events smoothly.

---

## 🐙 9. GitHub Version Control Commands

To upload this project to your GitHub repository:

```bash
# Initialize git repository
git init

# Stage all files
git add .

# Create initial commit
git commit -m "Initial project: Campus Resource Optimizer for BCA AI & DS"

# Set main branch
git branch -M main

# Link remote GitHub repository (replace with your repo URL)
git remote add origin YOUR_GITHUB_REPOSITORY_URL

# Push to GitHub
git push -u origin main
```

---

## 🎓 10. College Project Viva / Presentation Q&A

- **Q: How does conflict detection work?**
  - **A:** The system checks if an existing confirmed booking for the same resource on the same date has overlapping times using the mathematical interval condition: `(new_start < existing_end) AND (new_end > existing_start)`.
- **Q: How does the recommendation feature work?**
  - **A:** It filters rooms by type, checks that room capacity is sufficient, verifies equipment availability, and sorts candidates to select the room whose capacity is closest to the class size to maximize space efficiency.
